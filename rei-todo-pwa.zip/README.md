# れいのToDo PWA版 💖

## 📱 iPhone・Android対応のかわいいToDo管理アプリ

れいちゃんと一緒に楽しくタスク管理ができるPWA（Progressive Web App）版です！

### ✨ 特徴

- **📱 iPhone・Android対応** - ホーム画面に追加してアプリのように使える
- **💖 れいちゃんの可愛い反応** - タスクの追加・完了時にキュートなメッセージ
- **📅 日時管理機能** - 期限設定と自動ソート、期限切れ通知
- **📶 オフライン対応** - ネット接続がなくても使える
- **🎨 美しいUI** - レスポンシブデザインとスムーズなアニメーション
- **⚡ 高速動作** - Service Workerによるキャッシュで快適
- **🔧 モジュール設計** - リファクタリング済みで保守性抜群
- **🧪 テスト機能内蔵** - 機能テスト・パフォーマンステスト対応

### 🚀 セットアップ方法

1. **ローカルサーバーで実行**
   ```bash
   # Python 3の場合
   python3 -m http.server 8000
   
   # Python 2の場合
   python -m SimpleHTTPServer 8000
   
   # Node.jsの場合
   npx http-server
   ```

2. **ブラウザでアクセス**
   - 通常版: `http://localhost:8000`
   - テスト版: `http://localhost:8000/test.html`
   - iPhone・AndroidのSafari/Chromeでも動作

3. **ホーム画面に追加**
   - Safari: 共有ボタン → "ホーム画面に追加"
   - Chrome: メニュー → "ホーム画面に追加"

### 📱 iPhone対応

- **PWA対応** - ホーム画面に追加可能
- **フルスクリーン表示** - ブラウザUIを隠してアプリライク
- **オフライン動作** - Service Workerによるキャッシュ
- **タッチ操作最適化** - タップ操作に最適化されたUI

### 🎯 主な機能

#### 基本機能
- ✅ タスクの追加・編集・削除
- 📅 期限設定（日付・時刻）
- 📊 進捗表示（プログレスバー）
- 🔄 自動ソート（期限順）

#### れいちゃんの機能
- 💬 状況に応じたメッセージ
- 😊 時間帯別の挨拶
- 🎉 完了時の祝福
- ⚠️ 期限切れ警告

#### PWA機能
- 📱 ホーム画面への追加
- 📶 オフライン動作
- ⚡ 高速キャッシュ
- 🔔 プッシュ通知対応（予定）

### 🎨 カスタマイズ

スタイルや機能は以下のファイルで変更できます：

- `style.css` - デザイン・レイアウト
- `app.js` - 機能・ロジック
- `manifest.json` - PWA設定
- `sw.js` - Service Worker設定

### 🌟 技術仕様

- **フロントエンド**: Vanilla JavaScript (ES6+)
- **スタイル**: CSS3 (Grid, Flexbox, Custom Properties)
- **PWA**: Service Worker + Web App Manifest
- **ストレージ**: localStorage
- **レスポンシブ**: Mobile-first design

### 🔧 開発者向け

#### ディレクトリ構造
```
rei-todo-pwa/
├── index.html          # メインHTML
├── app.js             # メインJavaScript
├── style.css          # スタイルシート
├── sw.js              # Service Worker
├── manifest.json      # PWAマニフェスト
├── icons/             # アプリアイコン
└── README.md          # このファイル
```

#### 必要なアイコン
以下のサイズのアイコンを `icons/` ディレクトリに配置してください：
- 72x72, 96x96, 128x128, 144x144, 152x152, 192x192, 384x384, 512x512

### 📞 サポート

何か問題があれば、れいちゃんが優しく教えてくれます！💖

---

### 🧪 テスト機能

#### テスト版の利用
- **テストページ**: `http://localhost:8000/test.html`
- **機能**: 機能テスト・パフォーマンステスト・テストデータ生成

#### テスト実行方法
```javascript
// ブラウザのコンソールで実行
runFunctionalTest();     // 機能テスト実行
runPerformanceTest();    // パフォーマンステスト実行
generateTestData();      // テストデータ生成
clearAllData();          // 全データクリア
```

#### 利用可能なテスト
- ✅ **機能テスト**: タスク操作・データ永続化・UI更新の動作確認
- 📊 **パフォーマンステスト**: 処理時間・メモリ使用量の計測
- 🎲 **テストデータ生成**: 動作確認用のサンプルタスク生成

### 🔧 リファクタリング済み

#### モジュール構成
```
js/
├── app-refactored-v2.js    # メインアプリケーション
├── functional-test.js      # 機能テストスクリプト
├── performance-test.js     # パフォーマンステストスクリプト
└── modules/
    ├── todo-manager.js     # タスク管理モジュール
    ├── exp-system.js       # 経験値システムモジュール
    └── ui-components.js    # UIコンポーネントモジュール
```

#### リファクタリングのメリット
- **保守性向上**: 機能ごとのモジュール分割
- **テスト容易性**: 各機能を独立してテスト可能
- **拡張性**: 新機能の追加が簡単
- **可読性**: コードが整理され理解しやすい

詳細は `REFACTORING_REPORT.md` をご覧ください。

**Enjoy coding with Rei! 🎉**
